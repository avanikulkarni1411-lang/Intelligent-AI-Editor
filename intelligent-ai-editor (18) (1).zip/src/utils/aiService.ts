/**
 * Intelligent AI Editor - AI Synthesis & Google Gemini API Client
 * Connects the frontend natural language UI to backend AI orchestrator & Google Gemini API.
 */

import { getApiUrl } from './apiConfig';

export interface AISynthesizeRequest {
  prompt: string;
  shell_type?: string;
  working_directory?: string;
  os_type?: string;
  model?: string;
  session_id?: string;
}

export interface AISynthesizeResponse {
  intent: string;
  shell: string;
  command: string;
  explanation: string;
  risk: 'LOW' | 'MEDIUM' | 'HIGH' | 'BLOCKED';
  risk_reasons?: string[];
  requires_confirmation: boolean;
  needs_clarification?: boolean;
  clarification_question?: string | null;
  is_blocked?: boolean;
  provider?: string;
  ai_online?: boolean;
  gemini_online?: boolean;
  fallback_active?: boolean;
  model?: string;
  working_directory?: string;
}

export interface AIChatResponse {
  session_id: string;
  response: string;
  extracted_command?: string;
  provider?: string;
  ai_online?: boolean;
  gemini_online?: boolean;
  fallback_active?: boolean;
}

export interface AIStatusInfo {
  provider: string;
  online: boolean;
  available: boolean;
  gemini_online?: boolean;
  default_model: string;
  model?: string;
  fallback_active?: boolean;
  available_models: string[];
  target_platform: string;
}

class AIService {
  public async getStatus(): Promise<AIStatusInfo> {
    try {
      const res = await fetch(getApiUrl('/api/v1/ai/status'));
      if (res.ok) {
        const json = await res.json();
        return json.data;
      }
    } catch (e) {
      console.warn('AI status check error:', e);
    }
    return {
      provider: 'gemini',
      online: false,
      available: false,
      gemini_online: false,
      default_model: 'gemini-2.5-flash',
      model: 'gemini-2.5-flash',
      fallback_active: true,
      available_models: ['gemini-2.5-flash', 'gemini-3.7-flash', 'gemini-3.1-flash-lite'],
      target_platform: 'windows'
    };
  }

  public async getModels(): Promise<string[]> {
    try {
      const res = await fetch(getApiUrl('/api/v1/ai/models'));
      if (res.ok) {
        const json = await res.json();
        if (Array.isArray(json.data)) return json.data;
        if (Array.isArray(json.data?.models)) return json.data.models;
      }
    } catch {
      // fallback
    }
    return ['gemini-2.5-flash', 'gemini-3.7-flash', 'gemini-3.1-flash-lite'];
  }

  public async synthesize(req: AISynthesizeRequest): Promise<AISynthesizeResponse> {
    try {
      const res = await fetch(getApiUrl('/api/v1/ai/synthesize'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: req.prompt,
          shell_type: req.shell_type || 'powershell',
          working_directory: req.working_directory,
          os_type: req.os_type || 'windows',
          model: req.model || 'gemini-2.5-flash',
          session_id: req.session_id || 'default'
        })
      });

      if (res.ok && res.headers.get('content-type')?.includes('application/json')) {
        const json = await res.json();
        if (json.success && json.data) {
          return json.data;
        }
      }
    } catch {
      // Fall through to deterministic synthesis
    }

    // Deterministic fallback synthesis (matches server logic when offline or on static Vercel)
    return this.deterministicSynthesize(req.prompt, req.shell_type || 'powershell', req.model || 'gemini-2.5-flash');
  }

  private deterministicSynthesize(prompt: string, shell: string, model: string): AISynthesizeResponse {
    const p = prompt.trim();
    const pl = p.toLowerCase();
    const isCmd = shell === 'cmd';

    // Blocked check
    if (pl.includes('format c:') || pl.includes('rm -rf /') || pl.includes('del /f /s /q c:')) {
      return {
        intent: 'Format system disk',
        shell,
        command: isCmd ? 'format C:' : 'Format-Volume -DriveLetter C',
        explanation: 'CRITICAL: This command formats the operating system drive.',
        risk: 'BLOCKED',
        requires_confirmation: true,
        needs_clarification: false,
        provider: 'gemini',
        ai_online: false,
        gemini_online: false,
        fallback_active: true,
        model
      };
    }

    // Ambiguous delete check
    if (pl === 'delete the files' || pl === 'delete files' || pl === 'remove files') {
      return {
        intent: 'Delete files in directory',
        shell,
        command: '',
        explanation: 'Clarification required to prevent accidental data loss.',
        risk: 'HIGH',
        requires_confirmation: true,
        needs_clarification: true,
        clarification_question: 'Which files or directory would you like to delete? Please specify a file name, pattern, or path.',
        provider: 'gemini',
        ai_online: false,
        gemini_online: false,
        fallback_active: true,
        model
      };
    }

    // Current directory
    if (pl.includes('current directory') || pl === 'pwd' || pl.includes('where am i')) {
      return {
        intent: 'Display current working directory',
        shell,
        command: isCmd ? 'cd' : 'Get-Location',
        explanation: isCmd ? 'Displays the current directory path.' : 'Gets the current working directory location.',
        risk: 'LOW',
        requires_confirmation: false,
        needs_clarification: false,
        provider: 'gemini',
        ai_online: false,
        gemini_online: false,
        fallback_active: true,
        model
      };
    }

    // Python files
    if (pl.includes('python file') || pl.includes('python scripts') || pl.includes('find all python')) {
      return {
        intent: 'Find all Python files recursively',
        shell,
        command: isCmd ? 'dir /s /b *.py' : 'Get-ChildItem -Recurse -Filter *.py',
        explanation: isCmd ? 'Recursively lists all Python files in bare format.' : 'Recursively retrieves all Python files matching the *.py filter.',
        risk: 'LOW',
        requires_confirmation: false,
        needs_clarification: false,
        provider: 'gemini',
        ai_online: false,
        gemini_online: false,
        fallback_active: true,
        model
      };
    }

    // All files
    if (pl.includes('all files') || pl.includes('show files') || pl.includes('list files') || pl === 'ls' || pl === 'dir') {
      return {
        intent: 'List all files and directories',
        shell,
        command: isCmd ? 'dir' : 'Get-ChildItem',
        explanation: isCmd ? 'Displays a list of files and subdirectories.' : 'Gets the files and folders in the current directory.',
        risk: 'LOW',
        requires_confirmation: false,
        needs_clarification: false,
        provider: 'gemini',
        ai_online: false,
        gemini_online: false,
        fallback_active: true,
        model
      };
    }

    // Python version
    if (pl.includes('python version') || pl.includes('check python')) {
      return {
        intent: 'Check installed Python version',
        shell,
        command: 'python --version',
        explanation: 'Prints the currently active Python runtime version.',
        risk: 'LOW',
        requires_confirmation: false,
        needs_clarification: false,
        provider: 'gemini',
        ai_online: false,
        gemini_online: false,
        fallback_active: true,
        model
      };
    }

    // Running processes
    if (pl.includes('running processes') || pl.includes('processes') || pl.includes('process list')) {
      return {
        intent: 'List active operating system processes',
        shell,
        command: isCmd ? 'tasklist' : 'Get-Process',
        explanation: isCmd ? 'Displays all currently running processes and memory usage.' : 'Gets the processes that are running on the system.',
        risk: 'LOW',
        requires_confirmation: false,
        needs_clarification: false,
        provider: 'gemini',
        ai_online: false,
        gemini_online: false,
        fallback_active: true,
        model
      };
    }

    // Create folder
    if (pl.includes('create a folder') || pl.includes('make folder') || pl.includes('mkdir')) {
      const match = p.match(/(?:called|named|folder)\s+['"]?([a-zA-Z0-9_-]+)['"]?/i);
      const name = match ? match[1] : 'test';
      return {
        intent: `Create a directory named '${name}'`,
        shell,
        command: isCmd ? `mkdir ${name}` : `New-Item -ItemType Directory -Name ${name}`,
        explanation: isCmd ? `Creates a new directory named ${name}.` : `Creates a new filesystem directory named ${name}.`,
        risk: 'MEDIUM',
        requires_confirmation: true,
        needs_clarification: false,
        provider: 'gemini',
        ai_online: false,
        gemini_online: false,
        fallback_active: true,
        model
      };
    }

    // Search pattern
    if (pl.includes('containing the word') || pl.includes('containing word') || pl.includes('search for error') || pl.includes('find error')) {
      const match = p.match(/word\s+['"]?([a-zA-Z0-9_-]+)['"]?/i);
      const word = match ? match[1] : 'error';
      return {
        intent: `Find files containing '${word}'`,
        shell,
        command: isCmd ? `findstr /s /i "${word}" *.*` : `Select-String -Path "*.*" -Pattern "${word}" -SimpleMatch`,
        explanation: `Searches across files for occurrences of the string "${word}".`,
        risk: 'LOW',
        requires_confirmation: false,
        needs_clarification: false,
        provider: 'gemini',
        ai_online: false,
        gemini_online: false,
        fallback_active: true,
        model
      };
    }

    // Generic safe default
    return {
      intent: `Execute: ${p}`,
      shell,
      command: isCmd ? `echo "${p}"` : `Write-Output "${p}"`,
      explanation: `Echoes "${p}" to the terminal.`,
      risk: 'LOW',
      requires_confirmation: false,
      needs_clarification: false,
      provider: 'gemini',
      ai_online: false,
      gemini_online: false,
      fallback_active: true,
      model
    };
  }

  public async chat(message: string, shellType: string = 'powershell', cwd: string = '.'): Promise<AIChatResponse> {
    try {
      const res = await fetch(getApiUrl('/api/v1/ai/chat'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message,
          shell_type: shellType,
          working_directory: cwd
        })
      });

      if (res.ok && res.headers.get('content-type')?.includes('application/json')) {
        const json = await res.json();
        return json.data;
      }
    } catch {
      // Fall through to deterministic chat
    }

    const synth = this.deterministicSynthesize(message, shellType, 'gemini-2.5-flash');
    return {
      session_id: 'default',
      response: `Here is the recommended command for your request:\n\n\`\`\`${shellType}\n${synth.command}\n\`\`\`\n\n${synth.explanation}`,
      extracted_command: synth.command,
      provider: 'gemini',
      ai_online: false,
      gemini_online: false,
      fallback_active: true
    };
  }
}

export const aiService = new AIService();
