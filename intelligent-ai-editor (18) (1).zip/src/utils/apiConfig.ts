/// <reference types="vite/client" />

/**
 * Intelligent AI Editor - Centralized API Configuration
 * Production deployment on Vercel uses same-origin relative URLs (/api/*).
 * VITE_API_URL is optional and only used for local/remote development override if provided.
 */

// Production on Vercel uses same-origin relative API paths (/api/...)
const envApiUrl = typeof import.meta !== 'undefined' ? (import.meta as any).env?.VITE_API_URL : '';
export const API_BASE_URL: string = (envApiUrl || '').replace(/\/$/, '');

/**
 * Returns the URL for an API endpoint.
 * In production on Vercel, returns the same-origin relative endpoint (e.g. /api/v1/ai/chat).
 */
export function getApiUrl(path: string): string {
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  if (!API_BASE_URL) {
    return normalizedPath;
  }
  return `${API_BASE_URL}${normalizedPath}`;
}

/**
 * Returns the WebSocket URL for bidirectional terminal streaming.
 */
export function getWsUrl(path: string): string {
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  if (API_BASE_URL) {
    const wsProto = API_BASE_URL.startsWith('https') ? 'wss:' : 'ws:';
    const host = API_BASE_URL.replace(/^https?:\/\//, '');
    return `${wsProto}//${host}${normalizedPath}`;
  }
  if (typeof window !== 'undefined') {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    return `${protocol}//${window.location.host}${normalizedPath}`;
  }
  return normalizedPath;
}
