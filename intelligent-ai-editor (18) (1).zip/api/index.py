"""
Intelligent AI Editor - Vercel Python Serverless Function Entrypoint
Exposes the authoritative FastAPI app for single-project Vercel deployment.
"""
import sys
import os

# Add project root and backend directory to sys.path so modules can be imported seamlessly
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
backend_dir = os.path.join(project_root, "backend")

for p in (backend_dir, project_root):
    if p not in sys.path:
        sys.path.insert(0, p)

# Set VERCEL environment flag if running in serverless function
os.environ.setdefault("VERCEL", "1")

# Import the existing authoritative FastAPI application
try:
    from backend.main import app  # noqa: E402, F401
except ImportError:
    from main import app  # noqa: E402, F401
