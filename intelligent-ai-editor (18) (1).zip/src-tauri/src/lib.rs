use tauri::{AppHandle, Manager, Runtime};

#[tauri::command]
fn get_system_info() -> serde_json::Value {
    serde_json::json!({
        "os": std::env::consts::OS,
        "arch": std::env::consts::ARCH,
        "default_shell": if cfg!(target_os = "windows") { "powershell.exe" } else { "bash" },
        "status": "ready"
    })
}

#[tauri::command]
async fn minimize_window<R: Runtime>(_app: AppHandle<R>, window: tauri::Window<R>) -> Result<(), String> {
    window.minimize().map_err(|e| e.to_string())
}

#[tauri::command]
async fn toggle_maximize_window<R: Runtime>(_app: AppHandle<R>, window: tauri::Window<R>) -> Result<(), String> {
    if window.is_maximized().map_err(|e| e.to_string())? {
        window.unmaximize().map_err(|e| e.to_string())
    } else {
        window.maximize().map_err(|e| e.to_string())
    }
}

#[tauri::command]
async fn close_window<R: Runtime>(_app: AppHandle<R>, window: tauri::Window<R>) -> Result<(), String> {
    window.close().map_err(|e| e.to_string())
}

#[tauri::command]
async fn execute_local_command(
    command: String,
    shell_type: Option<String>,
    working_directory: Option<String>,
) -> Result<serde_json::Value, String> {
    let shell = shell_type.unwrap_or_else(|| "powershell".to_string());
    let cwd = working_directory.unwrap_or_else(|| ".".to_string());

    let (program, args) = if cfg!(target_os = "windows") {
        if shell.to_lowercase().contains("cmd") {
            ("cmd.exe", vec!["/C".to_string(), command.clone()])
        } else {
            ("powershell.exe", vec!["-NoProfile".to_string(), "-NonInteractive".to_string(), "-Command".to_string(), command.clone()])
        }
    } else {
        ("bash", vec!["-c".to_string(), command.clone()])
    };

    let start = std::time::Instant::now();
    let mut cmd = std::process::Command::new(program);
    cmd.args(&args);
    if !cwd.is_empty() && std::path::Path::new(&cwd).exists() {
        cmd.current_dir(&cwd);
    }

    match cmd.output() {
        Ok(output) => {
            let duration_ms = start.elapsed().as_millis();
            let stdout = String::from_utf8_lossy(&output.stdout).to_string();
            let stderr = String::from_utf8_lossy(&output.stderr).to_string();
            let exit_code = output.status.code().unwrap_or(0);
            Ok(serde_json::json!({
                "command": command,
                "shell_type": shell,
                "exit_code": exit_code,
                "stdout": stdout,
                "stderr": stderr,
                "execution_time_ms": duration_ms,
                "working_directory": cwd,
                "status": if exit_code == 0 { "SUCCESS" } else { "FAILED" }
            }))
        }
        Err(e) => Err(format!("Local command execution failed: {}", e)),
    }
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .plugin(tauri_plugin_fs::init())
        .plugin(tauri_plugin_process::init())
        .invoke_handler(tauri::generate_handler![
            get_system_info,
            minimize_window,
            toggle_maximize_window,
            close_window,
            execute_local_command
        ])
        .setup(|app| {
            let window = app.get_webview_window("main");
            if let Some(w) = window {
                #[cfg(debug_assertions)]
                {
                    // Open devtools automatically in debug mode if needed
                    // w.open_devtools();
                }
                println!("Intelligent AI Editor Desktop Window initialized successfully.");
            }
            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("error while running Intelligent AI Editor desktop application");
}
