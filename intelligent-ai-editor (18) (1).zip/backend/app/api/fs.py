"""
Intelligent AI Editor - Filesystem Management Endpoints
Provides strictly sandboxed workspace filesystem access (read, write, create, delete, list).
All operations are confined within the application's dedicated workspace directory.
Path traversal (../, ..\\), root escapes, symlink escapes, and Windows system paths are rejected.
"""
import os
import shutil
from datetime import datetime
from typing import Optional, List, Dict, Any
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field
from app.core.config import settings
from app.schemas.common import BaseResponse
from app.core.logging import logger

router = APIRouter(prefix="/fs", tags=["Filesystem"])


def get_safe_workspace_root() -> str:
    ws_dir = settings.WORKSPACE_DIR
    if os.environ.get("VERCEL") or not os.access(".", os.W_OK):
        if not os.path.isabs(ws_dir) or ws_dir.startswith("./"):
            ws_dir = "/tmp/workspace"
    try:
        os.makedirs(ws_dir, exist_ok=True)
    except Exception:
        ws_dir = "/tmp/workspace"
        os.makedirs(ws_dir, exist_ok=True)

    # Seed default sample files if empty
    try:
        if not os.listdir(ws_dir):
            os.makedirs(os.path.join(ws_dir, "src"), exist_ok=True)
            with open(os.path.join(ws_dir, "README.md"), "w", encoding="utf-8") as f:
                f.write("# Project Workspace\n\nSandboxed workspace for Intelligent AI Editor.\n")
            with open(os.path.join(ws_dir, "package.json"), "w", encoding="utf-8") as f:
                f.write('{\n  "name": "workspace-app",\n  "version": "1.0.0"\n}\n')
            with open(os.path.join(ws_dir, "src", "index.ts"), "w", encoding="utf-8") as f:
                f.write('console.log("Welcome to Intelligent AI Editor workspace");\n')
    except Exception:
        pass

    return os.path.realpath(os.path.abspath(ws_dir))


def get_safe_workspace_path(req_path: Optional[str] = None, must_exist: bool = False, is_delete: bool = False) -> str:
    """
    Validates and resolves a requested path strictly inside the configured workspace directory.
    Rejects directory traversal, null bytes, UNC paths, and paths escaping the workspace.
    """
    real_workspace = get_safe_workspace_root()

    if not req_path or req_path.strip() in ("", ".", "/"):
        if is_delete:
            raise HTTPException(status_code=403, detail="Access denied: Cannot delete the root workspace directory")
        return real_workspace

    clean = req_path.strip()

    # Reject null bytes
    if "\0" in clean:
        raise HTTPException(status_code=400, detail="Invalid path: Null byte detected")

    # Reject UNC paths or drive root overrides outside workspace
    if clean.startswith("\\\\") or clean.startswith("//"):
        raise HTTPException(status_code=400, detail="Invalid path: UNC network paths not allowed")

    # Resolve relative to workspace if not absolute, or test absolute path
    if os.path.isabs(clean):
        resolved = os.path.abspath(clean)
    else:
        # Prevent traversal tricks before join
        normalized_clean = os.path.normpath(clean)
        if normalized_clean.startswith("..") or "/../" in clean.replace("\\", "/"):
            raise HTTPException(status_code=403, detail="Access denied: Path traversal outside workspace boundary is forbidden")
        resolved = os.path.abspath(os.path.join(real_workspace, normalized_clean))

    # Check commonpath against real_workspace
    try:
        common = os.path.commonpath([real_workspace, resolved])
        if common != real_workspace:
            raise HTTPException(status_code=403, detail="Access denied: Path is outside permitted workspace boundary")
    except ValueError:
        raise HTTPException(status_code=403, detail="Access denied: Path crosses filesystem boundaries")

    # Symlink escape verification
    # Resolve any existing components to verify real target doesn't escape workspace
    check_cursor = resolved
    while check_cursor and not os.path.exists(check_cursor) and check_cursor != os.path.dirname(check_cursor):
        check_cursor = os.path.dirname(check_cursor)

    if os.path.exists(check_cursor):
        real_check = os.path.realpath(check_cursor)
        try:
            if os.path.commonpath([real_workspace, real_check]) != real_workspace:
                raise HTTPException(status_code=403, detail="Access denied: Symlink escapes workspace boundary")
        except ValueError:
            raise HTTPException(status_code=403, detail="Access denied: Path crosses filesystem boundaries")

    if os.path.exists(resolved):
        real_resolved = os.path.realpath(resolved)
        try:
            if os.path.commonpath([real_workspace, real_resolved]) != real_workspace:
                raise HTTPException(status_code=403, detail="Access denied: Symlink escapes workspace boundary")
        except ValueError:
            raise HTTPException(status_code=403, detail="Access denied: Path crosses filesystem boundaries")

    if must_exist and not os.path.exists(resolved):
        raise HTTPException(status_code=404, detail="File or directory not found")

    if is_delete and (resolved == real_workspace or resolved == workspace_root):
        raise HTTPException(status_code=403, detail="Access denied: Cannot delete root workspace directory")

    return resolved


class FileItem(BaseModel):
    name: str
    path: str
    type: str  # "file" or "directory"
    size: str
    modified: str


class DirectoryListResponse(BaseModel):
    cwd: str
    files: List[FileItem]


class FileReadRequest(BaseModel):
    path: str


class FileReadResponse(BaseModel):
    path: str
    content: str


class FileWriteRequest(BaseModel):
    path: str
    content: str = ""


class FileCreateRequest(BaseModel):
    path: str
    type: str = "file"  # "file" or "directory"


class FileDeleteRequest(BaseModel):
    path: str


def _format_size(size_bytes: int) -> str:
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{(size_bytes / 1024):.1f} KB"
    else:
        return f"{(size_bytes / (1024 * 1024)):.1f} MB"


@router.get("/list", response_model=BaseResponse[DirectoryListResponse])
async def list_directory(dir: Optional[str] = Query(None, description="Target directory path relative to workspace")):
    try:
        target_dir = get_safe_workspace_path(dir, must_exist=True)
        if not os.path.isdir(target_dir):
            raise HTTPException(status_code=400, detail="Target path is not a directory")

        workspace_root = os.path.realpath(os.path.abspath(settings.WORKSPACE_DIR))
        items: List[FileItem] = []
        for entry in os.scandir(target_dir):
            try:
                stat_res = entry.stat()
                is_dir = entry.is_dir()
                size_str = "DIR" if is_dir else _format_size(stat_res.st_size)
                mtime_str = datetime.fromtimestamp(stat_res.st_mtime).isoformat()
                
                rel_path = os.path.relpath(entry.path, workspace_root)
                items.append(FileItem(
                    name=entry.name,
                    path=rel_path,
                    type="directory" if is_dir else "file",
                    size=size_str,
                    modified=mtime_str
                ))
            except Exception:
                continue

        # Sort: directories first, then alphabetical
        items.sort(key=lambda x: (0 if x.type == "directory" else 1, x.name.lower()))
        rel_cwd = os.path.relpath(target_dir, workspace_root)
        display_cwd = "." if rel_cwd == "." else rel_cwd
        data = DirectoryListResponse(cwd=display_cwd, files=items)
        return BaseResponse(success=True, data=data)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error listing directory: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/read", response_model=BaseResponse[FileReadResponse])
async def read_file(req: FileReadRequest):
    try:
        file_path = get_safe_workspace_path(req.path, must_exist=True)
        if os.path.isdir(file_path):
            raise HTTPException(status_code=400, detail="Path is a directory, not a readable file")

        with open(file_path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()

        workspace_root = os.path.realpath(os.path.abspath(settings.WORKSPACE_DIR))
        rel_path = os.path.relpath(file_path, workspace_root)

        return BaseResponse(
            success=True,
            data=FileReadResponse(path=rel_path, content=content)
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error reading file: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/write", response_model=BaseResponse[Dict[str, Any]])
async def write_file(req: FileWriteRequest):
    try:
        file_path = get_safe_workspace_path(req.path, must_exist=False)
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(req.content)

        workspace_root = os.path.realpath(os.path.abspath(settings.WORKSPACE_DIR))
        rel_path = os.path.relpath(file_path, workspace_root)

        return BaseResponse(
            success=True,
            message="File saved successfully",
            data={"path": rel_path}
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error writing file: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/create", response_model=BaseResponse[Dict[str, Any]])
async def create_file_or_dir(req: FileCreateRequest):
    try:
        target_path = get_safe_workspace_path(req.path, must_exist=False)
        is_dir = req.type == "directory"

        if is_dir:
            os.makedirs(target_path, exist_ok=True)
        else:
            os.makedirs(os.path.dirname(target_path), exist_ok=True)
            if not os.path.exists(target_path):
                with open(target_path, "w", encoding="utf-8") as f:
                    f.write("")

        workspace_root = os.path.realpath(os.path.abspath(settings.WORKSPACE_DIR))
        rel_path = os.path.relpath(target_path, workspace_root)

        return BaseResponse(
            success=True,
            message=f"{'Directory' if is_dir else 'File'} created successfully",
            data={"path": rel_path}
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error creating file/directory: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/delete", response_model=BaseResponse[Dict[str, Any]])
async def delete_file_or_dir(req: FileDeleteRequest):
    try:
        target_path = get_safe_workspace_path(req.path, must_exist=True, is_delete=True)

        if os.path.isdir(target_path):
            shutil.rmtree(target_path)
        else:
            os.remove(target_path)

        workspace_root = os.path.realpath(os.path.abspath(settings.WORKSPACE_DIR))
        rel_path = os.path.relpath(target_path, workspace_root)

        return BaseResponse(
            success=True,
            message="Item deleted successfully",
            data={"path": rel_path}
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting file/directory: {e}")
        raise HTTPException(status_code=500, detail=str(e))
