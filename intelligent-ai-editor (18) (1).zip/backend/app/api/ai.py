"""
Intelligent AI Editor - AI Endpoints
"""
import sys
from fastapi import APIRouter, HTTPException
from app.ai.orchestrator import ai_orchestrator
from app.ai.gemini_client import gemini_client
from app.ai.model_manager import model_manager
from app.core.config import settings
from app.schemas.ai import CommandSynthesisRequest, CommandSynthesisResponse, ChatMessageRequest, ChatMessageResponse
from app.schemas.common import BaseResponse

router = APIRouter(prefix="/ai", tags=["AI Engine"])

@router.get("/status")
async def get_ai_status():
    """Returns AI Engine availability, Google Gemini model status, and platform configuration."""
    is_up = await gemini_client.is_available()
    models = await model_manager.get_available_models()
    return BaseResponse(
        success=True,
        data={
            "provider": "gemini",
            "online": is_up,
            "available": is_up,
            "gemini_online": is_up,
            "default_model": settings.DEFAULT_MODEL,
            "model": settings.DEFAULT_MODEL,
            "fallback_active": not is_up,
            "available_models": models,
            "target_platform": "windows" if sys.platform == "win32" else sys.platform
        }
    )

@router.post("/synthesize", response_model=BaseResponse[CommandSynthesisResponse])
async def synthesize_command(req: CommandSynthesisRequest):
    try:
        result = await ai_orchestrator.synthesize_command(req)
        return BaseResponse(success=True, data=result, message="Command synthesized successfully.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/chat", response_model=BaseResponse[ChatMessageResponse])
async def chat_assistant(req: ChatMessageRequest):
    try:
        response_text = await gemini_client.generate(prompt=req.message, model=req.model, temperature=req.temperature)
        if not response_text:
            response_text = f"Intelligent AI: I have processed your inquiry on '{req.message}'. Use the terminal to execute necessary scripts."

        res = ChatMessageResponse(
            session_id=req.session_id,
            response=response_text
        )
        return BaseResponse(success=True, data=res)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/models")
async def list_models():
    models = await model_manager.get_available_models()
    return BaseResponse(success=True, data=models)
